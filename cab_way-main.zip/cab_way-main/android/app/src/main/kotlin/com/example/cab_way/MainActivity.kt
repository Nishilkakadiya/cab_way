package com.example.cab_way

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
